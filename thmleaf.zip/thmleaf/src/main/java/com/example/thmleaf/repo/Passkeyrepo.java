package com.example.thmleaf.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.thmleaf.entity.Passkey;

public interface Passkeyrepo extends JpaRepository<Passkey , Long> {
    
}
