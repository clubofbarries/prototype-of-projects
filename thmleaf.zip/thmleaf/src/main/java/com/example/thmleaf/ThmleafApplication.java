package com.example.thmleaf;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ThmleafApplication {

	public static void main(String[] args) {
		SpringApplication.run(ThmleafApplication.class, args);
	}

}
