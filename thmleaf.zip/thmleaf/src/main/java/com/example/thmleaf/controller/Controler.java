package com.example.thmleaf.controller;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.thmleaf.entity.Passkey;
import com.example.thmleaf.entity.User;
import com.example.thmleaf.repo.Repo;

import org.springframework.ui.Model;

@Controller
public class Controler {


    // @Autowired
    // User user;

    @Autowired
    Repo repo;

    @GetMapping("/register")
    public String register(Model model){

        User user = new User();
        model.addAttribute("userForm", user);

        

        List<String> List = Arrays.asList("developer", "commerce");

        model.addAttribute("listProfession", List);

        return "register-form";
    }

    @PostMapping("register/save")
    public String submit(Model model, @ModelAttribute("userForm") User user ){
        System.out.println(user);

        repo.save(user);
        // User user2 = new User(0, user);
            return "save";
            
        }
    



    


}
