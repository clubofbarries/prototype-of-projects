package com.example.thmleaf;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ThmleafApplicationTests {

	@Test
	void contextLoads() {
	}

}
