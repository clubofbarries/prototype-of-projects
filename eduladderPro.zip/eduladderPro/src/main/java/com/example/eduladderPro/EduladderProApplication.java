package com.example.eduladderPro;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EduladderProApplication {
	// RestTemplate eRestTemplate = new RestTemplate();
	
	public static void main(String[] args) {
		SpringApplication.run(EduladderProApplication.class, args);
	}

}
