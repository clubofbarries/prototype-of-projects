package com.example.eduladderPro.Repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;
// import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import com.mysql.cj.MysqlConnection;
import com.mysql.*;


import com.example.eduladderPro.Entity.User;

@Repository
public interface UserRepository extends JpaRepository<User, Integer>, CrudRepository<User, Integer> {

    
    User findByUsernameAndPassword(String username, String password);

    User findTopByUsername(String username);

    User findTopByPassword(String password);

}

