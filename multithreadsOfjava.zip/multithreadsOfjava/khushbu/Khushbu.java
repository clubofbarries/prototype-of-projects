package khushbu;


public class Khushbu{



    public void khushbukaname(){
        
        // for(int i = 0; i < 50; i++){
            System.out.println("i am khusbu");
            System.out.println();
        
        // }
    }

    public void khushbukaage(){
        System.out.println("my age is 85");
    }

}