import khushbu.Khushbu;
import unnati.Unnati;

public class Main extends Thread {
    


    @Override
    public void run(){
        Khushbu khusbu = new Khushbu();
        Unnati unnati = new Unnati();

        unnati.unnatikaname();
        khusbu.khushbukaname();
        khusbu.khushbukaage();
        unnati.unnatikaage();
        // System.out.println("new name something");

        
    }

    public static void main(String[] args) {
        
        
        // Main main2 = new Main();
        
        for(int i = 0; i < 200; i++){
            
            Main main = new Main();
            main.start();

        }
        // main2.start();
    }


}
