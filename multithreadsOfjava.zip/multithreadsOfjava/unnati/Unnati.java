package unnati;


public class Unnati {
    
    public void unnatikaname(){
        
        // for(int i = 0; i < 50; i++){
            System.out.println("i am unnati");
        
        // }
    }

    
    public void unnatikaage(){
        System.out.println("my age is 89");
    }
}
