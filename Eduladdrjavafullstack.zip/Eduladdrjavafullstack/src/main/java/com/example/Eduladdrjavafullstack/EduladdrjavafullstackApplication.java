package com.example.Eduladdrjavafullstack;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EduladdrjavafullstackApplication {

	public static void main(String[] args) {
		SpringApplication.run(EduladdrjavafullstackApplication.class, args);
	}

}
